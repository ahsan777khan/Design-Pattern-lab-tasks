/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mediator;
public class ConcreteColleaque2 extends BaseComponent{
    public void doOperationC(){
        System.out.println("Colleaque 2 performed operation C.");
    }
    public void doOperationD(){
        System.out.println("Colleaque 2 performed operation D.");
    }
}
