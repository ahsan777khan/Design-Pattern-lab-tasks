/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Mediator;
public class ConcreteColleaque1 extends BaseComponent{
    public void doOperationA(){
        System.out.println("Colleaque 1 performed operation A.");
    }
    public void doOperationB(){
        System.out.println("Colleaque 1 performed operation B.");
    }
}