package Command.javaCore_example;

public interface Command {
	public void execute();
}
